public class Academia {
    
    private int alunos;

    public static int acessos;

    public Academia() {
        this.alunos = alunos;
    }
    
    public void atualiza(int alunos) {
        alunos++;
    }
}
