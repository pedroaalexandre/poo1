import java.util.ArrayList;
import java.util.List;

public class Aluno {

    private String codigo;

    private String nome;

    private String telefone;
    
    private int acessos;

    int categoria;

    public Aluno(String codigo, String nome, String telefone, int acessos) {
        this.codigo = codigo;
        this.nome = nome;
        this.telefone = telefone;
        this.acessos = acessos;
    }

    public Aluno(String codigo, String nome, String telefone, int acessos, int categoria) {
        this.codigo = codigo;
        this.nome = nome;
        this.telefone = telefone;
        this.acessos = acessos;
        this.categoria = categoria;
        Academia.acessos++;
    }

    
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getAcessos() {
        return acessos;
    }

    public void setAcessos(int acessos) {
        this.acessos = acessos;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public String exibe() {
        return "Código: " + codigo + "\nNome: " + nome + "\nTelefone: " + telefone + "\nCategoria: " + categoria;
    }

    public String exibe(int categoria) {
        return "Código: " + codigo + "\nNome: " + nome + "\nTelefone: " + telefone + "\nCategoria: " + categoria + "\nAcessos: " + acessos;
    }

}
